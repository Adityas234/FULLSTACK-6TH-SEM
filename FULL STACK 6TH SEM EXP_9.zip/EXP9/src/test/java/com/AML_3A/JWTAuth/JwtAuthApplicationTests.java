package com.AML_3A.JWTAuth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
